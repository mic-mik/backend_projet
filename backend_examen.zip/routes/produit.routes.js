const { produitsListe } = require("../controllers/produit.controllers");

const router = require("express").Router();

router.get("/", produitsListe);

module.exports = router;
