const { getProduits } = require("../queries/produit.queries");

exports.produitsListe = async (req, res, next) => {
  try {
    const produits = await getProduits();
    res.send(produits);
  } catch (error) {
    next(error);
  }
};
