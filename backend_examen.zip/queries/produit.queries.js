const Produit = require("../database/models/produit.model");

exports.getProduits = () => {
  return Produit.find().sort({ _id: -1 });
};
